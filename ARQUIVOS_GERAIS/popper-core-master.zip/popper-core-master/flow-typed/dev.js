// @flow

declare var __DEV__: boolean;

declare var browser: any;

declare var TEST_URL: string;
