// @flow
import { createPopper, popperGenerator } from './index';

// eslint-disable-next-line import/no-unused-modules
export { createPopper, popperGenerator };
